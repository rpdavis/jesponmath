/**
 * JepsonMath → Aeries Grade Transfer Extension
 * Content script - runs on Aeries gradebook pages
 *
 * This script interacts with the Aeries gradebook DOM to:
 * 1. Identify student rows by student ID or name
 * 2. Find assignment columns by name
 * 3. Fill in scores from JepsonMath export data
 */

console.log('🎓 JepsonMath Aeries Transfer: Content script loaded');

// Listen for messages from the popup
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.action === 'PASTE_GRADES') {
    handlePasteGrades(message.data)
      .then(result => sendResponse(result))
      .catch(err => sendResponse({ success: false, message: err.message }));
    return true; // Keep the message channel open for async response
  }

  if (message.action === 'DETECT_PAGE') {
    sendResponse(detectAeriesPage());
    return true;
  }
});

/**
 * Detect what kind of Aeries page we're on.
 */
function detectAeriesPage() {
  const url = window.location.href;
  const pageTitle = document.title || '';

  // Check for gradebook
  const isGradebook = url.includes('Gradebook') ||
    url.includes('gradebook') ||
    pageTitle.toLowerCase().includes('gradebook') ||
    document.querySelector('[class*="gradebook"]') !== null ||
    document.querySelector('[id*="gradebook"]') !== null;

  // Check for scores page
  const isScores = url.includes('Scores') ||
    url.includes('scores') ||
    document.querySelector('table.scores-table, .score-entry, [class*="score"]') !== null;

  return {
    url,
    pageTitle,
    isGradebook,
    isScores,
    isAeries: url.includes('aeries.net'),
  };
}

/**
 * Main function to paste grades into the Aeries gradebook.
 */
async function handlePasteGrades(gradeData) {
  console.log('📋 Starting grade paste process...');
  console.log('Data:', gradeData.metadata);

  // Strategy 1: Try to find a standard gradebook table
  const result = await tryGradebookTable(gradeData);
  if (result.success) return result;

  // Strategy 2: Try score input fields
  const result2 = await tryScoreInputFields(gradeData);
  if (result2.success) return result2;

  // Strategy 3: Show a floating overlay to help the user manually
  return showManualAssistOverlay(gradeData);
}

/**
 * Strategy 1: Find gradebook table and fill in scores.
 */
async function tryGradebookTable(gradeData) {
  // Look for tables on the page
  const tables = document.querySelectorAll('table');
  let gradebookTable = null;

  for (const table of tables) {
    // Heuristic: a gradebook table has student names in rows and assignments in columns
    const headers = table.querySelectorAll('th, thead td');
    const rows = table.querySelectorAll('tbody tr, tr');

    if (headers.length >= 3 && rows.length >= 2) {
      gradebookTable = table;
      break;
    }
  }

  if (!gradebookTable) {
    return { success: false, message: 'Could not find gradebook table on this page.' };
  }

  console.log('Found gradebook table:', gradebookTable);

  // Map column indices to standard codes
  const headerCells = gradebookTable.querySelectorAll('th, thead td');
  const columnMap = new Map(); // standardCode -> column index

  headerCells.forEach((cell, index) => {
    const headerText = cell.textContent.trim();
    // Try to match with our standard headers
    gradeData.headers.forEach((header, hIndex) => {
      if (hIndex >= 2) { // Skip "Student ID" and "Student Name"
        if (headerText.includes(header) || header.includes(headerText)) {
          columnMap.set(hIndex, index);
        }
      }
    });
  });

  if (columnMap.size === 0) {
    return { success: false, message: 'Could not match any standard columns in the Aeries gradebook.' };
  }

  // Map student rows to our data
  const rows = gradebookTable.querySelectorAll('tbody tr, tr:not(:first-child)');
  let matched = 0;
  let skipped = 0;

  for (const row of rows) {
    const cells = row.querySelectorAll('td');
    if (cells.length < 2) continue;

    // Try to identify student
    const rowText = Array.from(cells).map(c => c.textContent.trim()).join(' ');
    const studentRow = findMatchingStudent(rowText, gradeData);

    if (studentRow) {
      // Fill in scores
      for (const [dataIndex, colIndex] of columnMap) {
        const scoreValue = studentRow[dataIndex];
        if (scoreValue && colIndex < cells.length) {
          const cell = cells[colIndex];
          const input = cell.querySelector('input');
          if (input) {
            setInputValue(input, extractScore(scoreValue));
            matched++;
          }
        }
      }
    } else {
      skipped++;
    }
  }

  return {
    success: matched > 0,
    matched,
    skipped,
    message: matched > 0
      ? `Pasted ${matched} scores across ${columnMap.size} standards.`
      : 'Found table but could not match any students.',
  };
}

/**
 * Strategy 2: Find individual score input fields.
 */
async function tryScoreInputFields(gradeData) {
  // Look for score input fields
  const inputs = document.querySelectorAll('input[type="text"], input[type="number"], input:not([type])');
  const scoreInputs = Array.from(inputs).filter(input => {
    const name = (input.name || '').toLowerCase();
    const id = (input.id || '').toLowerCase();
    const cls = (input.className || '').toLowerCase();
    return name.includes('score') || name.includes('grade') || name.includes('point') ||
           id.includes('score') || id.includes('grade') ||
           cls.includes('score') || cls.includes('grade');
  });

  if (scoreInputs.length === 0) {
    return { success: false, message: 'No score input fields found.' };
  }

  // This is for single-student score entry pages
  // We'd need to figure out which student and assignment we're looking at
  return { success: false, message: 'Individual score entry not yet supported. Use the gradebook view.' };
}

/**
 * Strategy 3: Show a floating manual-assist overlay.
 * This shows a side panel with the grade data so the teacher
 * can easily reference scores while manually entering them.
 */
function showManualAssistOverlay(gradeData) {
  // Remove existing overlay if present
  const existing = document.getElementById('jepsonmath-overlay');
  if (existing) existing.remove();

  // Create overlay
  const overlay = document.createElement('div');
  overlay.id = 'jepsonmath-overlay';
  overlay.innerHTML = `
    <div class="jm-overlay-header">
      <h3>📊 JepsonMath Grade Data</h3>
      <div class="jm-overlay-controls">
        <button id="jm-minimize" title="Minimize">_</button>
        <button id="jm-close" title="Close">✕</button>
      </div>
    </div>
    <div class="jm-overlay-body" id="jm-overlay-body">
      <div class="jm-search">
        <input type="text" id="jm-search-input" placeholder="Search student..." />
      </div>
      <div class="jm-table-container" id="jm-table-container">
        <!-- Table rendered dynamically -->
      </div>
      <p class="jm-hint">
        💡 Tip: Click a score to copy it to your clipboard, then paste into the Aeries field.
      </p>
    </div>
  `;

  document.body.appendChild(overlay);

  // Render the data table
  renderOverlayTable(gradeData, '');

  // Set up event listeners
  document.getElementById('jm-close').addEventListener('click', () => overlay.remove());
  document.getElementById('jm-minimize').addEventListener('click', () => {
    const body = document.getElementById('jm-overlay-body');
    body.style.display = body.style.display === 'none' ? 'block' : 'none';
  });

  document.getElementById('jm-search-input').addEventListener('input', (e) => {
    renderOverlayTable(gradeData, e.target.value);
  });

  // Make overlay draggable
  makeDraggable(overlay);

  return {
    success: true,
    matched: 0,
    skipped: 0,
    message: 'Could not auto-fill. Showing grade reference panel — click scores to copy them.',
  };
}

/**
 * Render the overlay data table, filtered by search term.
 */
function renderOverlayTable(gradeData, searchTerm) {
  const container = document.getElementById('jm-table-container');
  if (!container) return;

  const filtered = searchTerm
    ? gradeData.rows.filter(row =>
        row[1].toLowerCase().includes(searchTerm.toLowerCase()) ||
        row[0].toLowerCase().includes(searchTerm.toLowerCase())
      )
    : gradeData.rows;

  let html = '<table class="jm-data-table"><thead><tr>';
  gradeData.headers.forEach(h => {
    html += `<th>${escapeHtml(h)}</th>`;
  });
  html += '</tr></thead><tbody>';

  filtered.forEach(row => {
    html += '<tr>';
    row.forEach((cell, idx) => {
      if (idx >= 2 && cell) {
        // Score cells are clickable
        html += `<td class="jm-score-cell" data-score="${escapeHtml(cell)}" title="Click to copy">${escapeHtml(cell)}</td>`;
      } else {
        html += `<td>${escapeHtml(cell)}</td>`;
      }
    });
    html += '</tr>';
  });

  if (filtered.length === 0) {
    html += `<tr><td colspan="${gradeData.headers.length}" style="text-align:center;color:#94a3b8;padding:20px;">No students match your search</td></tr>`;
  }

  html += '</tbody></table>';
  container.innerHTML = html;

  // Add click handlers to score cells
  container.querySelectorAll('.jm-score-cell').forEach(cell => {
    cell.addEventListener('click', async () => {
      const score = cell.dataset.score;
      // Extract just the score number (e.g., "5/8" -> "5")
      const numericScore = extractScore(score);
      try {
        await navigator.clipboard.writeText(numericScore);
        cell.classList.add('jm-copied');
        cell.title = 'Copied!';
        setTimeout(() => {
          cell.classList.remove('jm-copied');
          cell.title = 'Click to copy';
        }, 1000);
      } catch (err) {
        console.error('Copy failed:', err);
      }
    });
  });
}

// ─── Helper Functions ──────────────────────────────────────────────────────

/**
 * Find a matching student row in our data based on text from the Aeries page.
 */
function findMatchingStudent(rowText, gradeData) {
  const normalizedText = rowText.toLowerCase().replace(/\s+/g, ' ');

  for (const row of gradeData.rows) {
    const studentId = row[0];
    const studentName = row[1];

    // Match by student ID
    if (studentId && normalizedText.includes(studentId.toLowerCase())) {
      return row;
    }

    // Match by name (LastName, FirstName format)
    if (studentName) {
      const nameParts = studentName.toLowerCase().split(',').map(p => p.trim());
      if (nameParts.length === 2) {
        const lastName = nameParts[0];
        const firstName = nameParts[1];
        if (normalizedText.includes(lastName) && normalizedText.includes(firstName)) {
          return row;
        }
      }
    }
  }

  return null;
}

/**
 * Extract the numeric score from a formatted string.
 * Examples: "5/8" -> "5", "80%" -> "80", "5" -> "5"
 */
function extractScore(value) {
  if (!value) return '';

  // Handle "score/total" format — extract the score
  const slashMatch = value.match(/^(\d+)\/\d+$/);
  if (slashMatch) return slashMatch[1];

  // Handle percentage
  const percentMatch = value.match(/^(\d+)%$/);
  if (percentMatch) return percentMatch[1];

  // Return as-is if it's already a number
  return value;
}

/**
 * Set an input field's value programmatically, triggering
 * React/Angular/Vue change events as needed.
 */
function setInputValue(input, value) {
  // For React-based inputs
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype, 'value'
  ).set;
  nativeInputValueSetter.call(input, value);

  // Trigger multiple event types to ensure the framework picks it up
  input.dispatchEvent(new Event('input', { bubbles: true }));
  input.dispatchEvent(new Event('change', { bubbles: true }));
  input.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));

  // Visual feedback
  input.style.backgroundColor = '#d1fae5';
  setTimeout(() => {
    input.style.backgroundColor = '';
  }, 2000);
}

/**
 * Make an element draggable.
 */
function makeDraggable(element) {
  const header = element.querySelector('.jm-overlay-header');
  let isDragging = false;
  let startX, startY, startLeft, startTop;

  header.addEventListener('mousedown', (e) => {
    if (e.target.tagName === 'BUTTON') return;
    isDragging = true;
    startX = e.clientX;
    startY = e.clientY;
    const rect = element.getBoundingClientRect();
    startLeft = rect.left;
    startTop = rect.top;
    header.style.cursor = 'grabbing';
  });

  document.addEventListener('mousemove', (e) => {
    if (!isDragging) return;
    element.style.left = (startLeft + e.clientX - startX) + 'px';
    element.style.top = (startTop + e.clientY - startY) + 'px';
    element.style.right = 'auto';
  });

  document.addEventListener('mouseup', () => {
    isDragging = false;
    header.style.cursor = 'grab';
  });
}

/**
 * Escape HTML special characters.
 */
function escapeHtml(text) {
  const div = document.createElement('div');
  div.textContent = text || '';
  return div.innerHTML;
}
