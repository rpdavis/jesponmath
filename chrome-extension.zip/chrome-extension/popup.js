/**
 * JepsonMath → Aeries Grade Transfer Extension
 * Popup script - manages the popup UI and orchestrates grade pasting
 */

let gradeData = null;

// DOM elements
const statusCard = document.getElementById('status-card');
const statusValue = document.getElementById('status-value');
const statsSection = document.getElementById('stats-section');
const studentCount = document.getElementById('student-count');
const standardCount = document.getElementById('standard-count');
const previewSection = document.getElementById('preview-section');
const previewHeader = document.getElementById('preview-header');
const previewBody = document.getElementById('preview-body');
const pasteBtn = document.getElementById('paste-btn');
const previewBtn = document.getElementById('preview-btn');
const reloadBtn = document.getElementById('reload-btn');
const messageEl = document.getElementById('message');

// Initialize popup
document.addEventListener('DOMContentLoaded', () => {
  loadGradeData();
  setupEventListeners();
});

function setupEventListeners() {
  pasteBtn.addEventListener('click', pasteGradesIntoAeries);
  previewBtn.addEventListener('click', togglePreview);
  reloadBtn.addEventListener('click', loadGradeData);
}

/**
 * Load grade data from Chrome storage (stored by the content script
 * or pasted from JepsonMath clipboard data).
 */
async function loadGradeData() {
  showMessage('Loading data...', 'info');

  try {
    // Try reading from Chrome storage first
    const stored = await chrome.storage.local.get('jepsonmath_grades');
    if (stored.jepsonmath_grades) {
      gradeData = stored.jepsonmath_grades;
      updateUI();
      hideMessage();
      return;
    }

    // Try reading from clipboard
    try {
      const clipText = await navigator.clipboard.readText();
      if (clipText && clipText.includes('\t')) {
        gradeData = parseClipboardData(clipText);
        if (gradeData) {
          // Save to storage for persistence
          await chrome.storage.local.set({ jepsonmath_grades: gradeData });
          updateUI();
          hideMessage();
          return;
        }
      }
    } catch (clipErr) {
      console.log('Clipboard read not available:', clipErr.message);
    }

    // No data found
    gradeData = null;
    updateUI();
    showMessage('No grade data found. Copy standards from JepsonMath first.', 'error');
  } catch (err) {
    console.error('Error loading grade data:', err);
    showMessage('Error loading data: ' + err.message, 'error');
  }
}

/**
 * Parse tab-delimited clipboard data from JepsonMath.
 */
function parseClipboardData(text) {
  const lines = text.trim().split('\n');
  if (lines.length < 2) return null;

  const headers = lines[0].split('\t');
  if (headers.length < 3 || headers[0] !== 'Student ID') return null;

  const rows = [];
  for (let i = 1; i < lines.length; i++) {
    const cols = lines[i].split('\t');
    if (cols.length >= 2) {
      rows.push(cols);
    }
  }

  if (rows.length === 0) return null;

  return {
    headers,
    rows,
    standardCodes: headers.slice(2), // Everything after Student ID and Student Name
    metadata: {
      exportDate: new Date().toISOString().split('T')[0],
      totalStudents: rows.length,
      totalStandards: headers.length - 2,
      assessmentCategory: 'Unknown',
    },
  };
}

/**
 * Update the popup UI with current data state.
 */
function updateUI() {
  if (gradeData && gradeData.rows && gradeData.rows.length > 0) {
    statusCard.className = 'status-card has-data';
    statusValue.className = 'status-value ready';
    statusValue.textContent = `✅ ${gradeData.metadata.totalStudents} students, ${gradeData.metadata.totalStandards} standards ready`;

    statsSection.style.display = 'block';
    studentCount.textContent = gradeData.metadata.totalStudents;
    standardCount.textContent = gradeData.metadata.totalStandards;

    pasteBtn.disabled = false;
    previewBtn.disabled = false;
  } else {
    statusCard.className = 'status-card no-data';
    statusValue.className = 'status-value empty';
    statusValue.textContent = 'No data loaded';

    statsSection.style.display = 'none';
    pasteBtn.disabled = true;
    previewBtn.disabled = true;
  }
}

/**
 * Toggle the data preview table.
 */
function togglePreview() {
  if (previewSection.style.display === 'none') {
    renderPreview();
    previewSection.style.display = 'block';
    previewBtn.textContent = '🙈 Hide Preview';
  } else {
    previewSection.style.display = 'none';
    previewBtn.textContent = '👁️ Preview Data';
  }
}

/**
 * Render a preview of the data in a table.
 */
function renderPreview() {
  if (!gradeData) return;

  // Header
  const headerRow = document.createElement('tr');
  gradeData.headers.forEach(h => {
    const th = document.createElement('th');
    th.textContent = h;
    headerRow.appendChild(th);
  });
  previewHeader.innerHTML = '';
  previewHeader.appendChild(headerRow);

  // Body (first 10 rows)
  previewBody.innerHTML = '';
  const maxRows = Math.min(gradeData.rows.length, 10);
  for (let i = 0; i < maxRows; i++) {
    const tr = document.createElement('tr');
    gradeData.rows[i].forEach(cell => {
      const td = document.createElement('td');
      td.textContent = cell;
      tr.appendChild(td);
    });
    previewBody.appendChild(tr);
  }

  if (gradeData.rows.length > 10) {
    const tr = document.createElement('tr');
    const td = document.createElement('td');
    td.colSpan = gradeData.headers.length;
    td.textContent = `... and ${gradeData.rows.length - 10} more students`;
    td.style.textAlign = 'center';
    td.style.fontStyle = 'italic';
    td.style.color = '#94a3b8';
    tr.appendChild(td);
    previewBody.appendChild(tr);
  }
}

/**
 * Send grade data to the content script to paste into Aeries.
 */
async function pasteGradesIntoAeries() {
  if (!gradeData) {
    showMessage('No grade data loaded.', 'error');
    return;
  }

  pasteBtn.disabled = true;
  pasteBtn.textContent = '⏳ Pasting...';
  showMessage('Sending data to Aeries page...', 'info');

  try {
    // Get the active tab
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab) {
      showMessage('No active tab found.', 'error');
      return;
    }

    // Check if we're on an Aeries page
    if (!tab.url || !tab.url.includes('aeries.net')) {
      showMessage('Please navigate to Aeries gradebook first.', 'error');
      return;
    }

    // Send grade data to the content script
    const response = await chrome.tabs.sendMessage(tab.id, {
      action: 'PASTE_GRADES',
      data: gradeData,
    });

    if (response && response.success) {
      showMessage(
        `✅ Successfully pasted ${response.matched} of ${gradeData.rows.length} students!` +
          (response.skipped > 0 ? ` (${response.skipped} not found)` : ''),
        'success'
      );
    } else {
      showMessage(
        `⚠️ ${response?.message || 'Unknown error. Make sure you are on the Aeries gradebook page.'}`,
        'error'
      );
    }
  } catch (err) {
    console.error('Error pasting grades:', err);
    showMessage(
      'Could not connect to Aeries page. Make sure you are on the Aeries gradebook and refresh the page.',
      'error'
    );
  } finally {
    pasteBtn.disabled = false;
    pasteBtn.textContent = '📋 Paste Grades into Aeries';
  }
}

function showMessage(text, type) {
  messageEl.textContent = text;
  messageEl.className = type;
}

function hideMessage() {
  messageEl.style.display = 'none';
  messageEl.className = '';
}
